/**
 * Contains classes that implement most of the interactivity for the
 * {@link org.jfree.chart.fx.ChartViewer} and 
 * {@link org.jfree.chart.fx.ChartCanvas} components.
 */
package org.jfree.chart.fx.interaction;
