/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PS09460.controller;

import PS09460.dao.AccountDAO;
import PS09460.entity.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


/**
 *
 * @author phong
 */
@Controller
public class ShowAccountController{
    
    @Autowired
    public AccountDAO dao;
    public ShowAccountController() {
    }
    @RequestMapping(value = "hienthitaikhoan",method = RequestMethod.GET) 
    public String initiate(ModelMap model) {
        model.addAttribute("acc", new Account());
        model.addAttribute("accs", dao.getAll()); //lấy ra tất cả các tài khoản.
        return "hienthitaikhoan"; // hiện thị trang showAccount
    }

    //2. find...tìm kiếm theo username
    @RequestMapping(params = "find", method = RequestMethod.POST)
    public String find(@ModelAttribute("username1") String username, ModelMap model) {
        //model.addAttribute("accs", dao.getByName(username));

        // gọi hàm tìm kiếm dựa vào username
        model.addAttribute("accs", dao.getByName(username));
        return "hienthitaikhoan"; // hiện thị trang showAccount lên
    }

    //3. insert...thêm tài khoản
    @RequestMapping(params = "insert", method = RequestMethod.POST)
    public String insert(@ModelAttribute("acc") Account acc, ModelMap model) {
        
        try {
            dao.insert(acc); // thêm vào database
            return initiate(model); // gọi lại hàm load dữ liệu lên
        } catch (Exception ex) {
            model.addAttribute("errors", "Username đã tồn tại"); // nếu xuất hiện lỗi username đã tồn tại
            return initiate(model);
        }
        
    }

    //4. delete...thêm tài khoản
    @RequestMapping(params = "delete", method = RequestMethod.POST)
    public String delete(@ModelAttribute("acc") Account acc, ModelMap model) {
        //1.goi hàm delete
        dao.delete(acc.getUsername());
        model.addAttribute("accs",dao.getAll());
        return initiate(model); //2. load lại dữ liệu ...gọi hàm phía trên
    }
        //4. update...update tài khoản
    @RequestMapping(params = "update", method = RequestMethod.POST)
    public String update(@ModelAttribute("acc") Account acc, ModelMap model) {
        //1.goi hàm update
        dao.update(acc);
        model.addAttribute("accs",dao.getAll());
        return initiate(model); //2. load lại dữ liệu ...gọi hàm phía trên
    }
    
    @RequestMapping(params = "reset", method = RequestMethod.POST)
    public String reset(@ModelAttribute("acc") Account acc, ModelMap model) {
        model.addAttribute("accs",dao.getAll());
        return "hienthitaikhoan";
    }
}
