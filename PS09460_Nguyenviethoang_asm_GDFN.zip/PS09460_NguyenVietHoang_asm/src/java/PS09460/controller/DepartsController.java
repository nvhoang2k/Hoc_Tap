/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PS09460.controller;

import PS09460.dao.DepartsDAO;
import PS09460.entity.Departs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author phong
 */
@Controller
public class DepartsController {
    @Autowired
    public DepartsDAO dao;
    public DepartsController() {
    }
    @RequestMapping(value = "Departs",method = RequestMethod.GET) 
    public String initiate(ModelMap model) {
        model.addAttribute("dp", new Departs());
        model.addAttribute("dps", dao.getAll()); //lấy ra tất cả các tài khoản.
        return "Departs"; // hiện thị trang 
    }

    //2. find...tìm kiếm theo 
    @RequestMapping(params = "findName", method = RequestMethod.POST)
    public String find(@ModelAttribute("name1") String name, ModelMap model) {
        //model.addAttribute("accs", dao.getByName(username));

        // gọi hàm tìm kiếm dựa vào 
        model.addAttribute("dps", dao.getByName(name));
        return "Departs"; // hiện thị trang showAccount lên
    }

    //3. insert...thêm tài khoản
    @RequestMapping(params = "insertdp", method = RequestMethod.POST)
    public String insert(@ModelAttribute("dp") Departs acc, ModelMap model) {
        
        try {
            dao.insert(acc); // thêm vào database
            return initiate(model); // gọi lại hàm load dữ liệu lên
        } catch (Exception ex) {
            model.addAttribute("errors", "ID đã tồn tại"); // nếu xuất hiện lỗi username đã tồn tại
            return initiate(model);
        }
        
    }

    //4. delete...thêm tài khoản
    @RequestMapping(params = "deletedp", method = RequestMethod.POST)
    public String delete(@ModelAttribute("dp") Departs acc, ModelMap model) {
        //1.goi hàm delete
        dao.delete(acc.getId());
        model.addAttribute("dps",dao.getAll());
        return initiate(model); //2. load lại dữ liệu ...gọi hàm phía trên
    }
        //4. update...update tài khoản
    @RequestMapping(params = "updatedp", method = RequestMethod.POST)
    public String update(@ModelAttribute("dp") Departs acc, ModelMap model) {
        //1.goi hàm update
        dao.update(acc);
        model.addAttribute("dps",dao.getAll());
        return initiate(model); //2. load lại dữ liệu ...gọi hàm phía trên
    }

    @RequestMapping(params = "resetdp", method = RequestMethod.POST)
    public String reset(@ModelAttribute("acc") Departs acc, ModelMap model) {
        model.addAttribute("dps",dao.getAll());
        return "Departs";
    }
}
