/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PS09460.controller;

import PS09460.dao.StaffsDAO;
import PS09460.entity.Staffs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author phong
 */
@Controller
public class StaffsController {
    @Autowired
    public StaffsDAO dao;
    public StaffsController() {
    }
    @RequestMapping(value = "Staffs",method = RequestMethod.GET) 
    public String initiate(ModelMap model) {
        model.addAttribute("sf", new Staffs());
        model.addAttribute("sfs", dao.getAll()); //lấy ra tất cả các tài khoản.
        return "Staffs"; // hiện thị trang showAccount
    }

    //2. find...tìm kiếm theo username
    @RequestMapping(params = "findName1", method = RequestMethod.POST)
    public String find(@ModelAttribute("name2") String name, ModelMap model) {
        //model.addAttribute("accs", dao.getByName(username));

        // gọi hàm tìm kiếm dựa vào username
        model.addAttribute("sfs", dao.getByName(name));
        return "Staffs"; // hiện thị trang showAccount lên
    }

    //3. insert...thêm tài khoản
    @RequestMapping(params = "insertsf", method = RequestMethod.POST)
    public String insert(@ModelAttribute("sf") Staffs sf, ModelMap model) {
        
        try {
            dao.insert(sf); // thêm vào database
            return initiate(model); // gọi lại hàm load dữ liệu lên
        } catch (Exception ex) {
            model.addAttribute("errors", "id đã tồn tại"); // nếu xuất hiện lỗi username đã tồn tại
            return initiate(model);
        }
        
    }

    //4. delete...thêm tài khoản
    @RequestMapping(params = "deletesf", method = RequestMethod.POST)
    public String delete(@ModelAttribute("sf") Staffs acc, ModelMap model) {
        //1.goi hàm delete
        dao.delete(acc.getId());
        model.addAttribute("sfs",dao.getAll());
        return initiate(model); //2. load lại dữ liệu ...gọi hàm phía trên
    }
        //4. update...update tài khoản
    @RequestMapping(params = "updatesf", method = RequestMethod.POST)
    public String update(@ModelAttribute("sf") Staffs acc, ModelMap model) {
        //1.goi hàm update
        dao.update(acc);
        model.addAttribute("sfs",dao.getAll());
        return initiate(model); //2. load lại dữ liệu ...gọi hàm phía trên
    }
    
    @RequestMapping(params = "resetsf", method = RequestMethod.POST)
    public String reset(@ModelAttribute("sf") Staffs acc, ModelMap model) {
        model.addAttribute("sfs",dao.getAll());
        return "Staffs";
    }
}
