/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PS09460.dao;
import PS09460.entity.Account;
import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;




@Repository
public class AccountDAO {

    /**
     * Inject từ <bean class="...JdbcTemplate>
     */
    @Autowired
    protected JdbcTemplate jdbc;

    /**
     * Truy vấn 1 thực thể theo mã
     *
     * @param id mã thực thể cần truy vấn
     * @return thực thể truy vấn được
     */
    public Account getByUsername(Serializable Username) {
        String sql = "SELECT * FROM users WHERE Username=?";
        return jdbc.queryForObject(sql, getRowMapper(), Username);
    }
    /**
     * Truy vấn tất cả các thực thể
     *
     * @return danh sách thực thể truy vấn được
     */
    public List<Account> getAll() {
        String sql = "SELECT * FROM users";
        return getBySql(sql);
    }

    /**
     * Truy vấn các thực thể theo câu lệnh sql
     *
     * @param sql câu lệnh truy vấn
     * @return danh sách thực thể truy vấn được
     */
    protected List<Account> getBySql(String sql) {
        return jdbc.query(sql, getRowMapper());
    }

    /**
     * Ánh xạ cấu trúc bản ghi theo thuộc tính của bean
     *
     * @return ánh xạ bản ghi theo thuộc tính bean
     */
    private RowMapper<Account> getRowMapper() {
        return new BeanPropertyRowMapper<Account>(Account.class);
    }
    
    
    
    
    
    
    /**
     * Thêm mới 1 thực thể
     *
     * @param Account
     * @param acc là thực thể mới
     */
    public void insert(Account acc) {
        String sql = "INSERT INTO users VALUES (?,?,?)";
        jdbc.update(sql, acc.getUsername(),acc.getPassword(), acc.getFullname());
    }

    /**
     * Cập nhật thực thể
     *
     * @param acc là thực thể cần cập nhật
     */
    public void update(Account acc) {
        String sql = "UPDATE users SET password=? WHERE username=?";
        jdbc.update(sql, acc.getPassword(),acc.getFullname(), acc.getUsername());
    }

    /**
     * Xóa thực thể theo mã
     *
     * @param username mã thực thể cần xóa
     */
    public void delete(String username) {
        String sql = "DELETE FROM users WHERE username=?";
        jdbc.update(sql, username);
    }    

    
    ///////////////////////////////
    
    /**
     * Truy vấn thực thể theo tên
     *
     * @param username tên của thực thể cần truy vấn
     * @return danh sách thực thể truy vấn được
     */
    public List<Account> getByName(String username) {
         String sql = "SELECT * FROM users WHERE username LIKE ?";
        return jdbc.query(sql, getRowMapper(), "%" + username + "%");
    }    
}
