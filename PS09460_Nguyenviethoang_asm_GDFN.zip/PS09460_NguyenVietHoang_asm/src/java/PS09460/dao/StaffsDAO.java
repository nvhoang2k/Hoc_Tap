/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PS09460.dao;
import PS09460.entity.Staffs;
import java.io.Serializable;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author phong
 */
@Repository
public class StaffsDAO {
    @Autowired
    protected JdbcTemplate jdbc;

    /**
     * Truy vấn 1 thực thể theo mã
     *
     * @param id mã thực thể cần truy vấn
     * @return thực thể truy vấn được
     */
    public Staffs getById(Serializable id) {
        String sql = "SELECT * FROM Staffs WHERE id=?";
        return jdbc.queryForObject(sql, getRowMapper(), id);
    }
    /**
     * Truy vấn tất cả các thực thể
     *
     * @return danh sách thực thể truy vấn được
     */
    public List<Staffs> getAll() {
        String sql = "SELECT * FROM Staffs";
        return getBySql(sql);
    }

    /**
     * Truy vấn các thực thể theo câu lệnh sql
     *
     * @param sql câu lệnh truy vấn
     * @return danh sách thực thể truy vấn được
     */
    protected List<Staffs> getBySql(String sql) {
        return jdbc.query(sql, getRowMapper());
    }

    /**
     * Ánh xạ cấu trúc bản ghi theo thuộc tính của bean
     *
     * @return ánh xạ bản ghi theo thuộc tính bean
     */
    private RowMapper<Staffs> getRowMapper() {
        return new BeanPropertyRowMapper<Staffs>(Staffs.class);
    }
    
    
    
    
    
    
    /**
     * Thêm mới 1 thực thể
     *
     * @param Account
     * @param acc là thực thể mới
     */
    public void insert(Staffs acc) {
        String sql = "INSERT INTO users VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        jdbc.update(sql, acc.getId(), acc.getName(), acc.getGender(), acc.getBirthday(), acc.getBirthday(), 
                acc.getPhoto(), acc.getEmail(), acc.getPhone(), acc.getSalary(), acc.getNotes(), acc.getDepartId());
    }

    /**
     * Cập nhật thực thể
     *
     * @param acc là thực thể cần cập nhật
     */
    public void update(Staffs acc) {
        String sql = "UPDATE Staffs SET name=?, Gender=?, Birthday=?, Photo=?, Email=?, Phone=?, Salary=?, Notes=?, DepartId=? WHERE id=?";
        jdbc.update(sql, acc.getName(), acc.getGender(), acc.getBirthday(), 
                acc.getPhoto(), acc.getEmail(), acc.getPhone(), acc.getSalary(), acc.getNotes(), acc.getDepartId(),acc.getId());
    }

    /**
     * Xóa thực thể theo mã
     *
     * @param username mã thực thể cần xóa
     */
    public void delete(String id) {
        String sql = "DELETE FROM Staffs WHERE id=?";
        jdbc.update(sql, id);
    }    

    
    /**
     * Truy vấn thực thể theo tên
     *
     * @param username tên của thực thể cần truy vấn
     * @return danh sách thực thể truy vấn được
     */
    
    public List<Staffs> getByName(String name) {
         String sql = "SELECT * FROM Staffs WHERE id LIKE ?";
        return jdbc.query(sql, getRowMapper(), "%" + name + "%");
    }    
}
